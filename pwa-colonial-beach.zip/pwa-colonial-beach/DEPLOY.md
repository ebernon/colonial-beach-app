# Colonial Beach App — Deploy Guide

## Netlify Drop (fastest — 2 minutes, no account needed)
1. Go to app.netlify.com/drop
2. Drag the entire `public/` folder onto the page
3. Get a shareable URL instantly — done!

## Vercel (best — custom domain support)
1. Sign up free at vercel.com
2. npm install -g vercel
3. From this folder: vercel --prod
4. When asked "which directory": type `public`
5. Get your URL (e.g. colonial-beach-app.vercel.app)

## How friends install it on their phone
iPhone: Open URL in Safari → Share → Add to Home Screen
Android: Chrome auto-shows an Install banner

## How to update
Edit public/app.jsx → run `vercel --prod` again → everyone gets it instantly
